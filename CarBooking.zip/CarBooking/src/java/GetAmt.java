import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class GetAmt extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
            HttpSession hs=req.getSession(false);
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        String bno=req.getParameter("txtbno").trim();
              
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst=con.prepareStatement("select * from payment where bno=?");
        pst.setString(1,bno);
        ResultSet rs=pst.executeQuery();
        if(rs.next())
        {
            pw.print(rs.getString("amt"));
          
        }
        else
        {
            pw.println("fail");
        }
       
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}