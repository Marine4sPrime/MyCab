import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class MyWallet extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        HttpSession hs=req.getSession(false);
       
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        int amt=Integer.parseInt(req.getParameter("txtamt").trim());
                              
        Connection con=DB_Connection.get_DBConnection();
            
        PreparedStatement pst=con.prepareStatement("update customer set balance =balance+? where emailid =?");
        pst.setInt(1,amt);
        pst.setString(2,(String)(hs.getAttribute("A1")));
       
        pst.executeUpdate();
        pst.close();
        
        PreparedStatement pst1=con.prepareStatement("select balance from customer where emailid =?");
        pst1.setString(1,(String)(hs.getAttribute("A1")));
        ResultSet rs=pst1.executeQuery();
        rs.next();
         req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Amount added successfully to your account.<br/>Your new balance is"+rs.getString(1)+" </div>");       
         RequestDispatcher rd=req.getRequestDispatcher("my_wallet.jsp");
         rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}