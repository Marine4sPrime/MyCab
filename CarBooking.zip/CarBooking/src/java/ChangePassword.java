import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class ChangePassword extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
            
        HttpSession hs=req.getSession(false);
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
         
        String old=req.getParameter("txtoldpassword").trim();
        String nw=req.getParameter("txtnewpassword").trim();
       
              
        Connection con=DB_Connection.get_DBConnection();
            
        PreparedStatement pst=con.prepareStatement("select * from login where emailid=?");
        pst.setString(1,(String)(hs.getAttribute("A1")));
        ResultSet rs=pst.executeQuery();
        rs.next();
        if(rs.getString("password").equals(old))
        {
            PreparedStatement pst1=con.prepareStatement("update login set password =? where emailid=?");
            pst1.setString(1,nw);
            pst1.setString(2,(String)(hs.getAttribute("A1")));
            pst1.executeUpdate();
            pst1.close();
            req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Password changed successfully.</div>");       
           RequestDispatcher rd=req.getRequestDispatcher("changepassword.jsp");
            rd.forward(req, res);
         
        }
       

         req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Old password does not match.</div>");       
         RequestDispatcher rd=req.getRequestDispatcher("changepassword.jsp");
         rd.forward(req, res);
       
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}