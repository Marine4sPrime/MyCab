import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class View_Balance extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
         HttpSession hs=req.getSession(false);  
          
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        Connection con=DB_Connection.get_DBConnection();
            
        PreparedStatement pst=con.prepareStatement("select * from customer where emailid=?");
        pst.setString(1,(String)(hs.getAttribute("A1")));
       ResultSet rs= pst.executeQuery();
       rs.next();

         req.setAttribute("msg",rs.getString("balance"));
         
         RequestDispatcher rd=req.getRequestDispatcher("view_balance.jsp");
         rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}