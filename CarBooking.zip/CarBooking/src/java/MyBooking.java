    import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class MyBooking extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        String table="";
        try
        {
         HttpSession hs=req.getSession(false);  
        
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        Connection con=DB_Connection.get_DBConnection();
           
        PreparedStatement pst=con.prepareStatement("Select * from booking where emailid=?");
        pst.setString(1,(String)(hs.getAttribute("A1")));
        ResultSet rs= pst.executeQuery();
        table=table+"<table class='table table-bordered'><thead><tr><th>Booking no<th>Email<th>Car no<th>AC/NonAC<th>Start date<th>End date<th>Car type<th>Source<th>Destination</thead><tbody>";
       while(rs.next())
       {
           table=table+"<tr>";
           table=table+"<td>"+rs.getString("bno");
           table=table+"<td>"+rs.getString("emailid");
           table=table+"<td>"+rs.getString("carno");
           table=table+"<td>"+rs.getString("acnonac").toUpperCase();
           table=table+"<td>"+rs.getString("start_date");
           table=table+"<td>"+rs.getString("end_date");
           table=table+"<td>"+rs.getString("car_type").charAt(0)+" Seater";
           table=table+"<td>"+rs.getString("source");
           table=table+"<td>"+rs.getString("destination");
                     
       }
         table=table+"</tr></tbody></table>";
        req.setAttribute("msg", table); 
        RequestDispatcher rd=req.getRequestDispatcher("mybooking.jsp");
        rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}