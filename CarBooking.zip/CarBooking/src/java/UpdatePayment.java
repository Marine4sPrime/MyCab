import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;

public class UpdatePayment extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
            HttpSession hs=req.getSession(false);
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        String bno=req.getParameter("txtbno").trim();
        int amt=Integer.parseInt(req.getParameter("txtamt").trim());
       
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst=con.prepareStatement("select * from payment where bno=?");
        pst.setString(1,bno);
        ResultSet rs=pst.executeQuery();
        if(rs.next())
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Payment already updated.</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("updatepayment.jsp");
            rd.forward(req, res);
        }
        else
        {
            PreparedStatement pst1=con.prepareStatement("select * from booking where bno=?");
            pst1.setString(1,bno);
            ResultSet rs1=pst1.executeQuery();
            if(rs1.next()==false)
            {
                 req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Invalid booking no.</div>");       
                 RequestDispatcher rd=req.getRequestDispatcher("updatepayment.jsp");
                 rd.forward(req, res);

            }
             else if(rs1.getString("status").equalsIgnoreCase("cancelled"))
            {
                req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Cannot update payment for cancelled booking/div>");       
                RequestDispatcher rd=req.getRequestDispatcher("updatepayment.jsp");
                rd.forward(req, res);
            }
            else
            {
                PreparedStatement pst2=con.prepareStatement("insert into payment values(?,?,?)");
                pst2.setString(1,bno);
                pst2.setInt(2,amt);
                pst2.setString(3,"pending");
                pst2.executeUpdate();
                pst2.close();

                PreparedStatement pst3=con.prepareStatement("update booking set status=? where bno=?");
                pst3.setString(1,"completed");
                pst3.setString(2,bno);

                pst3.executeUpdate();
                pst3.close();
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth","true");
                p.put("mail.smtp.host","smtp.gmail.com");
                p.put("mail.smtp.port","587");

                Session s= Session.getInstance(p,new Authenticator()
                {
                        protected PasswordAuthentication getPasswordAuthentication() 
                        {
                                       return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                        }
                });
                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rs1.getString("emailid")));//here type recipient email id
                msg.setSubject("MyCar.com Payment update");
                String a="<h3>Total amt to be paid:"+amt+"/-</h3><br/><br/>Your booking details are as follows:<br/><br/>Booking no:"+bno+"<br/>Pickup:"+rs1.getString("source") +"<br/>Drop:"+rs1.getString("destination")+"<br/>Start date:"+rs1.getString("start_date")+"<br/>End date:"+rs1.getString("end_date")+"<br/>Car type:"+rs1.getString("car_type").charAt(0) +" Seater<br/>AC/NonAC:"+rs1.getString("acnonac").toUpperCase()+"<br/>Car no:"+rs1.getString("carno");
                msg.setContent(a, "text/html; charset=utf-8");
                Transport.send(msg);


                 req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Payment updated successfully.</div>");       
                 RequestDispatcher rd=req.getRequestDispatcher("updatepayment.jsp");
                 rd.forward(req, res);
            }

            }
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}