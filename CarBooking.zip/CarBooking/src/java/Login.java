import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;

public class Login extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
                
        try
        {
           
        String e=req.getParameter("txtemailid");
        String p=req.getParameter("txtpassword");
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst=con.prepareStatement("select * from login where emailid=? and password=?");
        pst.setString(1,e);
        pst.setString(2,p);
        ResultSet rs=pst.executeQuery();
        if(rs.next())
        {
            if(rs.getString("status").equalsIgnoreCase("activated"))
            {
               HttpSession hs=req.getSession(true);
                hs.setAttribute("A1", e);
              
                res.sendRedirect("home_login.jsp");
            }
            else
            {
                pw.println("<script> alert('Account not activated yet. Please check your email from more information')</script>");
                RequestDispatcher rd=req.getRequestDispatcher("home.jsp");
                rd.include(req, res);
                
            }
            
        }
        else
        {
           
             
             pw.println("<script> alert('Invalid userid or password');</script>");
             RequestDispatcher rd=req.getRequestDispatcher("home.jsp");
             rd.include(req, res);
                         
        }
         
        }
        catch(Exception e)
        {
            pw.println(e);
        }
        
    }
}