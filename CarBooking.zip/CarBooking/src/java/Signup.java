import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class Signup extends HttpServlet
{
    public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String fname=req.getParameter("txtfname").trim();
        String lname=req.getParameter("txtlname").trim();
        String email=req.getParameter("txtemail").trim();
        String mobile=req.getParameter("txtphone").trim();
        String password=req.getParameter("txtpassword").trim();
        int h=email.hashCode();//ALGORITHM TO GENERATE HASH VALUE TO SEND TO EMAILLINK
        
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst1=con.prepareStatement("select * from customer where emailid=?");
        pst1.setString(1, email);
        ResultSet rs=pst1.executeQuery();
        
        if(rs.next()==false)
        {
            PreparedStatement pst=con.prepareStatement("insert into customer values(?,?,?,?,?)");
            pst.setString(1,fname);
            pst.setString(2,lname);
            pst.setString(3,email);
            pst.setString(4,mobile);
            pst.setInt(5,0);
            
            pst.executeUpdate();
            pst.close();
            
            PreparedStatement pst2=con.prepareStatement("insert into login values(?,?,?)");
            pst2.setString(1, email);
            pst2.setString(2, password);
            pst2.setString(3, "Deactivated");
            pst2.executeUpdate();
            pst2.close();
            
            Properties p=new Properties();
            p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
            p.put("mail.smtp.auth","true");
            p.put("mail.smtp.host","smtp.gmail.com");
            p.put("mail.smtp.port","587");

            Session s= Session.getInstance(p,new Authenticator()
            {
                    protected PasswordAuthentication getPasswordAuthentication() 
                    {
                                   return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                    }
            });
            
            MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
            msg.setFrom(new InternetAddress(DB_Connection.SENDERS_EMAILID));
            msg.addRecipient(Message.RecipientType.TO,new InternetAddress(email));//here type recipient email id
            msg.setSubject("MyCar.com Activation");
            String a="We welcome you to the family of Mycar.com\nClick on activation link to activate your account\n<a href=http://localhost:8080/CarBooking/Activate_User.jsp?p1="+email+"&p2="+h+">Activation link</a>";
            msg.setContent(a, "text/html; charset=utf-8");
            Transport.send(msg);
            
            req.setAttribute("errormsg","<div class='alert alert-success' style='text-align: center;'>Success!Your account is successfully registered with us. <br/>An activation link is sent to your email id. <br/>Please click on that link to activate and start using your account.</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("signup.jsp");
            rd.forward(req, res);
                      
        }
        else
        {
            req.setAttribute("fname",fname);//these fields will stay for new registration if the email already exists
            req.setAttribute("lname",lname);
            req.setAttribute("phone",mobile);
            req.setAttribute("errormsg","<div class='alert alert-danger' style='height:70px'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>The specified email id is already registered with us.Try using a different one</div>");
            req.setAttribute("autofocus", "autofocus");
            RequestDispatcher rd=req.getRequestDispatcher("signup.jsp");
            rd.forward(req, res); 
        }
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}