import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;

public class PayMoney extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        HttpSession hs=req.getSession(false);
        
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        String bno=req.getParameter("txtbno").trim();
        int amt=Integer.parseInt(req.getParameter("txtamt").trim());
        
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement ps=con.prepareStatement("select * from payment where bno=?");
        ps.setString(1,bno);
        
        ResultSet rs=ps.executeQuery();
        rs.next();
        if(rs.getString("status").equalsIgnoreCase("paid"))
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Payment already updated for this booking id</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("pay_money.jsp");
            rd.forward(req, res);  
        }
        else
        {
            
            PreparedStatement pst=con.prepareStatement("select * from customer where emailid=?");
            pst.setString(1,(String)(hs.getAttribute("A1")));

            ResultSet rs1=pst.executeQuery();
            rs1.next();
            String name=rs1.getString("fname")+" "+rs1.getString("lname");
            if(rs1.getInt("balance")>=amt)
            {
                PreparedStatement pst1=con.prepareStatement("update payment set status=? where bno=?");
                pst1.setString(1,"Paid");
                pst1.setString(2,bno);
                pst1.executeUpdate();

                PreparedStatement pst2=con.prepareStatement("update customer set balance=? where emailid=?");
                pst2.setInt(1,(rs1.getInt("balance")-amt));
                pst2.setString(2,hs.getAttribute("A1").toString());
                pst2.executeUpdate();
                
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth","true");
                p.put("mail.smtp.host","smtp.gmail.com");
                p.put("mail.smtp.port","587");

                Session s= Session.getInstance(p,new Authenticator()
                {
                        protected PasswordAuthentication getPasswordAuthentication() 
                        {
                                       return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                        }
                });
                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rs1.getString("emailid")));//here type recipient email id
                msg.setSubject("MyCar.com payment invoice");
                String a="<h2>MyCar.com</h2><b>Thank you for making the payment:<br/><br/>The Details are as follows:</b><br/><br/><b>Booking no: </b>"+bno+"<br/><b>Amount paid: </b>"+amt+" /-<br/><b>Payment mode: </b> E-wallet";
                msg.setContent(a, "text/html; charset=utf-8");
                Transport.send(msg);


                req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Payment successfull</div>");       
                RequestDispatcher rd=req.getRequestDispatcher("addcar.jsp");
                rd.forward(req, res);
            }
            else
            {
                req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Insufficient balance in your account</div>");       
                RequestDispatcher rd=req.getRequestDispatcher("pay_money.jsp");
                rd.forward(req, res);
            }

            }
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}