import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class Enquiry extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String name=req.getParameter("txtname").trim();
        String email=req.getParameter("txtemail").trim();
        String mobile=req.getParameter("txtphone").trim();
        String pickup=req.getParameter("txtpickup").trim();
        String drop=req.getParameter("txtdrop").trim();
        String dt=req.getParameter("txtstartdate").trim();
              
        Connection con=DB_Connection.get_DBConnection();
            
        PreparedStatement pst=con.prepareStatement("insert into enquiry values(?,?,?,?,?,?)");
        pst.setString(1,name);
        pst.setString(2,email);
        pst.setString(3,mobile);
        pst.setString(4,pickup);
        pst.setString(5,drop);
        pst.setString(6,dt);

        pst.executeUpdate();
        pst.close();

         req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Thank you for showing interest in us. We will get back to you shortly</div>");       
         RequestDispatcher rd=req.getRequestDispatcher("enquiry.jsp");
         rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}