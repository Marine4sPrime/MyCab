import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class AddCar extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
            HttpSession hs=req.getSession(false);
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        String carno=req.getParameter("txtcarno").trim();
        String carname=req.getParameter("txtcarname").trim();
        String car_type=req.getParameter("car_type").trim();
                      
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst=con.prepareStatement("select * from car where carno=?");
        pst.setString(1,carno);
        ResultSet rs=pst.executeQuery();
        if(rs.next())
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Car details already exists</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("addcar.jsp");
            rd.forward(req, res);
        }
        else
        {
         
            PreparedStatement pst1=con.prepareStatement("insert into car values(?,?,?)");
            pst1.setString(1,carno);
            pst1.setString(2,carname);
            pst1.setString(3,car_type);

            pst1.executeUpdate();
            pst1.close();

             req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Car details added successfully</div>");       
             RequestDispatcher rd=req.getRequestDispatcher("addcar.jsp");
             rd.forward(req, res);
                      
        }
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}