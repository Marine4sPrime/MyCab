import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import java.text.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;

public class Booking extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        HttpSession hs=req.getSession(false);//if session does not exist it creates a new session 
        Connection con=DB_Connection.get_DBConnection();
        String name="",email="",mobile="",url="";
        try
        {
            if(hs==null)
            {
                name=req.getParameter("txtname").trim();
                email=req.getParameter("txtemail").trim();
                mobile=req.getParameter("txtphone").trim();
                url="home.jsp";
            }
            else
            {
                PreparedStatement pst=con.prepareStatement("select * from customer where emailid=?");
                pst.setString(1, hs.getAttribute("A1").toString());
                ResultSet rs=pst.executeQuery();
                rs.next();
                name=rs.getString("fname")+" "+rs.getString("lname");
                email=rs.getString("emailid");
                mobile=rs.getString("mobile");
                url="bookcar.jsp";
            }
        String pickup=req.getParameter("txtpickup").trim();
        String drop=req.getParameter("txtdrop").trim();
        String start=req.getParameter("txtstartdate").trim();
        String end=req.getParameter("txtenddate").trim();
        String car_type=req.getParameter("car_type").trim();
        String ac=req.getParameter("r1").trim();
        Calendar c=Calendar.getInstance();
        String bno=c.get(Calendar.YEAR)+""+c.get(Calendar.MONTH)+""+c.get(Calendar.DAY_OF_MONTH)+""+c.get(Calendar.MILLISECOND);
       
        PreparedStatement pst=con.prepareStatement("select * from car where car_type=?");
        pst.setString(1,car_type);
        ResultSet rs= pst.executeQuery();
        while(rs.next())
        {
            pw.println(bno);
            PreparedStatement pst1=con.prepareStatement("select * from booking where carno=? and status=?");
            pst1.setString(1, rs.getString("carno"));
            pst1.setString(2, "booked");
            ResultSet rs1=pst1.executeQuery();
            if(rs1.next()==false)
            {
                PreparedStatement pst2=con.prepareStatement("insert into booking values(?,?,?,?,?,?,?,?,?,?,?,?)");
                pst2.setString(1,bno);
                pst2.setString(2,name);
                pst2.setString(3,email);
                pst2.setString(4,mobile);
                pst2.setString(5,pickup);
                pst2.setString(6,drop);
                pst2.setString(7,start);
                pst2.setString(8,end);
                pst2.setString(9,car_type);
                pst2.setString(10,ac);
                pst2.setString(11, rs.getString("carno"));
                pst2.setString(12, "booked");
                pst2.executeUpdate();
                req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Booking done successfully & booking details is sent to your emailid<br/> Your booking no is "+bno+"</div>");       
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                Session s=Session.getDefaultInstance(p);//this session is secured session
                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(email));//here type recipient email id
                msg.setSubject("MyCar.com booking");
                String a="Your booking details are as follows:<br/><br/>Booking no:"+bno+"<br/>Pickup:"+pickup+"<br/>Drop:"+drop+"<br/>Start date:"+start+"<br/>End date:"+end+"<br/>Car type:"+car_type.charAt(0) +" Seater<br/>AC/NonAC:"+ac.toUpperCase()+"<br/>Car no:"+rs.getString("carno");
                msg.setText(a,"UTF-8","html");
                Transport t=s.getTransport("smtp");
                t.connect("smtp.gmail.com",DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);// here u have to type ur email id and password
                t.sendMessage(msg,msg.getAllRecipients());
                RequestDispatcher rd=req.getRequestDispatcher(url);
                rd.forward(req, res);
                break;
            }
         }
        SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
       
        rs.beforeFirst();
        boolean flag=false;
        
        while(rs.next())
        {
            PreparedStatement pst1=con.prepareStatement("select * from booking where carno=?");
            pst1.setString(1, rs.getString("carno"));
            pw.println(rs.getString("carno"));
            ResultSet rs1=pst1.executeQuery();
            while(rs1.next())
            {
               
                if((sf.parse(start).before(sf.parse(rs1.getString("start_date"))) && sf.parse(end).before(sf.parse(rs1.getString("start_date")))) || (sf.parse(start).after(sf.parse(rs1.getString("end_date"))) && sf.parse(end).after(sf.parse(rs1.getString("end_date")))) || (sf.parse(end).before(sf.parse(rs1.getString("start_date")))))
                {
                    flag=true;
                  //  pw.println("aa");
                }
                else
                {
                    flag=false;
                    break;
                }
            }
            if(flag==true)
            {
                PreparedStatement pst2=con.prepareStatement("insert into booking values(?,?,?,?,?,?,?,?,?,?,?,?)");
                pst2.setString(1,bno);
                pst2.setString(2,name);
                pst2.setString(3,email);
                pst2.setString(4,mobile);
                pst2.setString(5,pickup);
                pst2.setString(6,drop);
                pst2.setString(7,start);
                pst2.setString(8,end);
                pst2.setString(9,car_type);
                pst2.setString(10,ac);
                pst2.setString(11, rs.getString("carno"));
                pst2.setString(12, "booked");
                pst2.executeUpdate();
                req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Booking done successfully & booking details is sent to your emailid <br/> Your booking no is "+bno+"</div>");       
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                Session s=Session.getDefaultInstance(p);//this session is secured session
                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(email));//here type recipient email id
                msg.setSubject("MyCar.com booking");
                String a="Your booking details are as follows:\nBooking no:"+bno+"\nPickup:"+pickup+"\nDrop:"+drop+"\nStart date:"+start+"\nEnd date:"+end+"\nCar type:"+car_type+"\nAC/NonAC:"+ac+"\nCar no:"+rs.getString("carno");
                msg.setText(a,"UTF-8","html");
                Transport t=s.getTransport("smtp");
                t.connect("smtp.gmail.com",DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);// here u have to type ur email id and password
                t.sendMessage(msg,msg.getAllRecipients());
                RequestDispatcher rd=req.getRequestDispatcher(url);
                rd.forward(req, res);
                break;
            }
        }
        req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Sorry no cabs available</div>");       
        RequestDispatcher rd=req.getRequestDispatcher(url);
        rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}