import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;

public class CancelBooking extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
            HttpSession hs=req.getSession(false);//This method will check whether Session already existed for the request or not. If it existed then it will return the already existed Session
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
        String bno=req.getParameter("txtbno").trim();
        
       
        Connection con=DB_Connection.get_DBConnection();
        
        PreparedStatement pst=con.prepareStatement("select bno,datediff(start_date,now()),emailid,status from booking where bno=?");
        pst.setString(1,bno);
        ResultSet rs=pst.executeQuery();
        if(rs.next()==false)
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Invalid Booking no.</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("cancelbooking.jsp");
            rd.forward(req, res);
        }
        else if(rs.getString("status").equalsIgnoreCase("cancelled"))
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>This booking already cancelled</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("cancelbooking.jsp");
            rd.forward(req, res);
        }
        else if(rs.getInt(2)<2)
        {
            req.setAttribute("msg","<div class='alert alert-danger' style='text-align: center;'>Cancellations can only be done 2 days prior to journey date</div>");       
            RequestDispatcher rd=req.getRequestDispatcher("cancelbooking.jsp");
            rd.forward(req, res);
        }
        else
        {
            
            PreparedStatement pst1=con.prepareStatement("update booking set status='cancelled' where bno=?");
            pst1.setString(1,bno);
            pst1.executeUpdate();
                
                Properties p=new Properties();
                p.put("mail.smtp.starttls.enable","true");//here smtp donot get start security gets started
                p.put("mail.smtp.auth","true");
                p.put("mail.smtp.host","smtp.gmail.com");
                p.put("mail.smtp.port","587");

                Session s= Session.getInstance(p,new Authenticator()
                {
                        protected PasswordAuthentication getPasswordAuthentication() 
                        {
                                       return new PasswordAuthentication(DB_Connection.SENDERS_EMAILID,DB_Connection.SENDERS_PASSWORD);
                        }
                });
                MimeMessage msg=new MimeMessage(s);//multipurpose internet mail extension mime which can include special characters
                msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rs.getString("emailid")));//here type recipient email id
                msg.setSubject("MyCar.com booking cancellation confirmation");
                String a="<h3>The cancellation for Booking no:"+bno+" is successful";
                msg.setContent(a, "text/html; charset=utf-8");
                Transport.send(msg);


                 req.setAttribute("msg","<div class='alert alert-success' style='text-align: center;'>Booking cancelled successfully.</div>");       
                 RequestDispatcher rd=req.getRequestDispatcher("cancelbooking.jsp");
                 rd.forward(req, res);
            }

            
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}