import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class ForgotPassword1 extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        try
        {
        String c=req.getParameter("txtcode").trim();
        String c1=req.getParameter("hidden_code").trim();
        String e=req.getParameter("hidden_emailid").trim();
        String password=req.getParameter("txtnewpassword").trim();
        
        if(c.equals(c1))
        {
        Connection con=DB_Connection.get_DBConnection();
        PreparedStatement pst=con.prepareStatement("update login set password=? where emailid=?");
        pst.setString(1,password);
        pst.setString(2,e);
        pst.executeUpdate();
        
        req.setAttribute("errormsg","<div class='alert alert-success' style='height:70px;font-weight: bold'>Password reset successfully.<br> <a href=home.jsp>Click here</a> to login</div>");
        req.setAttribute("disabled","disabled");
        RequestDispatcher rd=req.getRequestDispatcher("forgotpassword1.jsp");
        rd.forward(req, res);
           
        }
        else
        {
             req.setAttribute("errormsg","<div class='alert alert-danger' style='height:70px;font-weight: bold'>Entered secret code does not match</div>");
            req.setAttribute("disabled","disabled");
            RequestDispatcher rd=req.getRequestDispatcher("forgotpassword1.jsp");
            rd.forward(req, res);
        }
        }
        catch(Exception e)
        {
            pw.println(e);
        }
        
    }
}