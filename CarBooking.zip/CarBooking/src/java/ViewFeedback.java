import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import p1.*;


public class ViewFeedback extends HttpServlet
{
    public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
    {
        PrintWriter pw=res.getWriter();
        res.setContentType("text/html");
        String table="";
        try
        {
        HttpSession hs=req.getSession(false);
      
        if(hs==null)
         {
             
            res.sendRedirect("home.jsp");
            return;
         }
              
        Connection con=DB_Connection.get_DBConnection();
            
        PreparedStatement pst=con.prepareStatement("Select * from feedback");
       ResultSet rs= pst.executeQuery();
       table=table+"<table class='table table-bordered'><thead><tr><th>Name<th>Email<th>Mobile<th>Feedback</thead><tbody>";
       while(rs.next())
       {
           table=table+"<tr>";
           table=table+"<td>"+rs.getString(1);
           table=table+"<td>"+rs.getString(2);
           table=table+"<td>"+rs.getString(3);
           table=table+"<td>"+rs.getString(4);
                     
       }
         table=table+"</tr></tbody></table>";
        req.setAttribute("msg", table);
        RequestDispatcher rd=req.getRequestDispatcher("viewfeedback.jsp");
        rd.forward(req, res);
                      
        }
        catch(Exception e)
        {
            pw.println(e);
        }

              
        
    }
}